package com.sos.api.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sos.api.model.Aluno;

@Repository
public interface AlunoRepository extends CrudRepository<Aluno, Long> {

}
