package com.sos.api.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Table (name = "tb_aluno")// Cria a tabela auto
@Entity
public class Aluno {
	
	// Atributos
		/* Isolado para enem:
		 * Preparatorio para IFRN: ( com turmas determinadas, sem limite de turmas, 40 alunos por turma) no form ter um campo para respon
		 * reforço : Apenas formularios
		 * imprimir formulario na hora do cadastro
		 */
		
		// Atributos para o banco
		/*Nome, RG. CPF, Endereço, telefone, data de nascimento, e-mail, ano que estuda, escola, 
		 * Materias, dias que vai estudar, horario, (modalidade)
		 * Mensalidade/Valor, data de pgmt, MOP(debito em conta, credito/debito, dinheiro, boleto)
		 * */
	
	// Gera os IDs auto
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private Long id;
	
	private String name;
	private String rg;
	private String cpf;
	private String telefone;
	private String dataNascimento;
	private String email;
	
	
	
	// Getts e Setts
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
	
	
}
