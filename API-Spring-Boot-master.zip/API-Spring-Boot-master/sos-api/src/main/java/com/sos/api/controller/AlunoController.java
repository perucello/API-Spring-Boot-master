package com.sos.api.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sos.api.model.Aluno;
import com.sos.api.repository.AlunoRepository;



@RequestMapping (value = "/aluno")
@RestController 
public class AlunoController {

	@Autowired
	private AlunoRepository alunoRepository;
	
	
	// Consulta Atravez do ID
	@GetMapping (value = "/{id}", produces = "application/json")
	public ResponseEntity<Aluno> buscar(@PathVariable (value = "id") Long id) {
		
		Optional<Aluno> cadast = alunoRepository.findById(id);
		
		return new ResponseEntity<Aluno>(cadast.get(), HttpStatus.OK);
	}
	
	
	// Consulta Todos
	@GetMapping (value = "/", produces = "application/json")
	public ResponseEntity<List<Aluno>> buscarTodos() {
		
		List<Aluno> list = (List<Aluno>) alunoRepository.findAll();
	
		return new ResponseEntity<List<Aluno>>(list, HttpStatus.OK);
	}
	
	// Salva um Registro
	@PostMapping(value = "/", produces = "application/json")
	public ResponseEntity<Aluno> salvar(@RequestBody Aluno aluno) {
		
		Aluno salvarAluno = alunoRepository.save(aluno);
		
		return new ResponseEntity<Aluno>(salvarAluno, HttpStatus.OK);
	}
	
	// Edita um Registro
	@PutMapping(value = "/", produces = "application/json")
	public ResponseEntity <Aluno> editar(@RequestBody Aluno aluno) {
		
		Aluno editarAluno = alunoRepository.save(aluno);
		
		return new ResponseEntity<Aluno>(editarAluno, HttpStatus.OK);
		
	}
	
	// Deleta um Registro
	@DeleteMapping (value = "/{id}", produces = "applacation/text")
	public String delete(@PathVariable (value = "id") Long id) {
		
		alunoRepository.deleteById(id);
		
		return "OK";
	}
	
}
